# GX1 Player

Android / Android TV video player using Media3 ExoPlayer.

## Features

- Open local video/audio files from the in-player menu
- Load/remove external SRT, VTT, SSA/ASS and TTML subtitles
- Enable/disable subtitles
- Remember playback position per video and resume the last selected video
- Audio pass-through toggle and build information

## Build locally

Requires JDK 17, Android SDK (compile SDK 34), and Gradle 8.7.

```bash
gradle wrapper --gradle-version 8.7
./gradlew :app:assembleDebug
```

The application ID is `com.example.gx1player`. Keep it unchanged for updates.

## GitHub Actions signing setup

The repository workflow creates a signed release APK on pushes to `main` and manual runs. Add these four repository Actions secrets under **Settings → Secrets and variables → Actions**:

- `ANDROID_KEYSTORE_BASE64`: base64 encoding of `GX1Player-release-key.jks`
- `ANDROID_KEYSTORE_PASSWORD`: the keystore password supplied separately with the key file
- `ANDROID_KEY_ALIAS`: `gx1player`
- `ANDROID_KEY_PASSWORD`: same as the keystore password

Never commit the `.jks` file or its password to the repository. Keep at least two secure backups of the keystore. Every future release must use this exact key and the same application ID. Losing the key prevents update-installing future APKs.

### Encode the keystore for the GitHub secret

Linux/macOS:

```bash
base64 -w 0 GX1Player-release-key.jks
```

On macOS, use `base64 GX1Player-release-key.jks` instead.

Windows PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes('GX1Player-release-key.jks'))
```

Copy the entire output into the `ANDROID_KEYSTORE_BASE64` secret. The GitHub Actions workflow fails rather than silently producing a differently signed APK if any signing secret is missing.

## First installation transition

The new key cannot update an APK signed with the old, unavailable key. Uninstall the old GX1 Player once, then install the first APK built with this key. This can remove app-private data. After that first install, every build signed with this same key and using the same application ID can update over the installed app without uninstalling.
