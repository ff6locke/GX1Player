plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Build number: GitHub run number in CI, or -PbuildNumber=N locally, else 1.
val buildNumber: Int = (System.getenv("GITHUB_RUN_NUMBER")
    ?: project.findProperty("buildNumber")?.toString()
    ?: "1").toInt()

android {
    namespace = "com.example.gx1player"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.gx1player"
        minSdk = 30          // Android TV 12 on the GX1 is well above this
        targetSdk = 34
        versionCode = buildNumber
        versionName = "1.0.$buildNumber"
        buildConfigField("String", "BUILD_NUMBER", "\"$buildNumber\"")
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Put the build number in the APK file name, e.g. gx1-player-debug-b42.apk
androidComponents {
    onVariants { variant ->
        variant.outputs.forEach { output ->
            output.outputFileName.set("gx1-player-${variant.name}-b$buildNumber.apk")
        }
    }
}

dependencies {
    val media3 = "1.4.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("androidx.media3:media3-common:$media3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
