package com.example.gx1player

import android.content.Context
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioCapabilities
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink

/**
 * Renderers for "audio pass-through" (bitstream) mode.
 *
 * In this mode the player never decodes compressed audio (AC-3, E-AC-3, DTS, TrueHD...)
 * to PCM on the box. Encoded frames are sent unchanged over HDMI (or S/PDIF) so the
 * AV receiver / soundbar does the decoding. Float output and software extension
 * decoders are disabled so nothing converts the stream.
 *
 * Whether a given codec actually passes through depends on what the connected
 * receiver reports in its EDID. AudioCapabilities.getCapabilities() reads that and
 * ExoPlayer only bitstreams formats the sink reports as supported; everything else
 * falls back to PCM decoding by the box.
 */
class PassthroughRenderersFactory(context: Context) : DefaultRenderersFactory(context) {

    init {
        // Software decoder extensions (FFmpeg etc.) would decode to PCM. Turn them off.
        setExtensionRendererMode(EXTENSION_RENDERER_MODE_OFF)
        setEnableFloatOutput(false)
    }

    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean
    ): AudioSink {
        return DefaultAudioSink.Builder(context)
            .setAudioCapabilities(AudioCapabilities.getCapabilities(context))
            .setEnableFloatOutput(false)
            .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
            .setAudioProcessors(emptyArray<AudioProcessor>())
            .build()
    }
}
