package com.example.gx1player

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {

    private lateinit var playerView: PlayerView
    private var player: ExoPlayer? = null
    private var mediaUri: Uri? = null
    private var passthrough = true
    private var resumePositionMs = 0L

    private val prefs by lazy { getSharedPreferences("gx1_player", MODE_PRIVATE) }

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {
                // Some providers don't grant persistable permissions; playback still works this session.
            }
            prefs.edit().putString("uri", uri.toString()).apply()
            mediaUri = uri
            resumePositionMs = 0L
            startPlayer()
        } else {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        passthrough = prefs.getBoolean("passthrough", true)

        playerView = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            setKeepContentOnPlayerReset(true)
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        }
        setContentView(playerView)

        mediaUri = intent?.data
            ?: prefs.getString("uri", null)?.let { Uri.parse(it) }

        if (mediaUri == null) {
            pickFile.launch(arrayOf("video/*", "audio/*"))
        }
    }

    override fun onStart() {
        super.onStart()
        if (player == null && mediaUri != null) startPlayer()
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }

    private fun startPlayer() {
        releasePlayer()
        val uri = mediaUri ?: return

        val renderers = if (passthrough) {
            PassthroughRenderersFactory(this)
        } else {
            DefaultRenderersFactory(this)
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val exo = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        exo.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioInputFormatChanged(
                eventTime: AnalyticsListener.EventTime,
                format: Format,
                decoderReuseEvaluation: DecoderReuseEvaluation?
            ) {
                // Shows the codec coming from the source; the actual path depends on the receiver.
                title = "GX1 Player - ${format.sampleMimeType ?: "audio"} " +
                        if (passthrough) "[passthrough]" else "[PCM]"
            }
        })

        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.seekTo(resumePositionMs)
        exo.prepare()
        exo.playWhenReady = true

        playerView.player = exo
        player = exo
    }

    private fun releasePlayer() {
        player?.let {
            resumePositionMs = it.currentPosition
            it.release()
        }
        player = null
        playerView.player = null
    }

    private fun togglePassthrough() {
        passthrough = !passthrough
        prefs.edit().putBoolean("passthrough", passthrough).apply()
        Toast.makeText(
            this,
            if (passthrough) "Audio pass-through ON (bitstream)" else "Audio pass-through OFF (decode on box)",
            Toast.LENGTH_SHORT
        ).show()
        // Renderers can only be chosen at player creation, so rebuild at the current position.
        startPlayer()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_MENU,
            KeyEvent.KEYCODE_INFO,
            KeyEvent.KEYCODE_BUTTON_Y -> {
                togglePassthrough()
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }
}
