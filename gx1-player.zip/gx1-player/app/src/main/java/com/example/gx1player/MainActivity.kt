package com.example.gx1player

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PREFS = "gx1_player"
        private const val KEY_LAST_URI = "last_uri"
        private const val KEY_PASSTHROUGH = "passthrough"
        private const val KEY_SUBS_ON = "subs_on"
        private const val KEY_SUBTITLE_1 = "subtitle_1|"
        private const val KEY_SUBTITLE_2 = "subtitle_2|"

        private const val MIN_RESUME_MS = 5_000L      // don't bother resuming under 5 s
        private const val END_MARGIN_MS = 10_000L     // within 10 s of the end counts as finished
        private const val SAVE_INTERVAL_MS = 5_000L   // periodic resume-position save

        private fun posKey(uri: Uri) = "pos|$uri"
    }

    private lateinit var playerView: PlayerView
    private var player: ExoPlayer? = null
    private var playingUri: Uri? = null      // the file the current player is actually playing
    private var mediaUri: Uri? = null        // the file selected by the user
    private var subtitle1Uri: Uri? = null   // first external subtitle track
    private var subtitle2Uri: Uri? = null   // second external subtitle track
    private var pickingSubtitleSlot = 1
    private var passthrough = true
    private var subtitlesEnabled = true

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private val periodicSave = object : Runnable {
        override fun run() {
            player?.let { if (it.isPlaying) savePosition(it) }
            handler.postDelayed(this, SAVE_INTERVAL_MS)
        }
    }

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) {
            if (mediaUri == null) finish()
            return@registerForActivityResult
        }
        takePermission(uri)
        prefs.edit().putString(KEY_LAST_URI, uri.toString()).apply()
        selectMedia(uri)
        startPlayer()
    }

    private val pickSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        takePermission(uri)
        if (pickingSubtitleSlot == 1) {
            subtitle1Uri = uri
        } else {
            subtitle2Uri = uri
        }
        subtitlesEnabled = true
        prefs.edit().putBoolean(KEY_SUBS_ON, true).apply()
        mediaUri?.let { video ->
            val key = if (pickingSubtitleSlot == 1) KEY_SUBTITLE_1 + video else KEY_SUBTITLE_2 + video
            prefs.edit().putString(key, uri.toString()).apply()
        }
        startPlayer()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        passthrough = prefs.getBoolean(KEY_PASSTHROUGH, true)
        subtitlesEnabled = prefs.getBoolean(KEY_SUBS_ON, true)

        playerView = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            setKeepContentOnPlayerReset(true)
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        }
        setContentView(playerView)

        val initial = intent?.data ?: prefs.getString(KEY_LAST_URI, null)?.let { Uri.parse(it) }
        if (initial != null) {
            selectMedia(initial)
        } else {
            pickVideo.launch(arrayOf("video/*", "audio/*"))
        }
    }

    override fun onStart() {
        super.onStart()
        if (player == null && mediaUri != null) startPlayer()
        handler.postDelayed(periodicSave, SAVE_INTERVAL_MS)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(periodicSave)
        releasePlayer()
    }

    // ---------- media selection & player ----------

    private fun selectMedia(uri: Uri) {
        mediaUri = uri
        prefs.edit().putString(KEY_LAST_URI, uri.toString()).apply()
        subtitle1Uri = prefs.getString(KEY_SUBTITLE_1 + uri, null)?.let { Uri.parse(it) }
        subtitle2Uri = prefs.getString(KEY_SUBTITLE_2 + uri, null)?.let { Uri.parse(it) }
    }

    private fun startPlayer() {
        releasePlayer()                        // saves the position of whatever was playing
        val uri = mediaUri ?: return

        val renderers = if (passthrough) {
            PassthroughRenderersFactory(this)
        } else {
            DefaultRenderersFactory(this)
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val exo = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        // Save immediately on pause/end/seek as well as on the periodic timer. This
        // reduces the chance of losing the resume point if Android kills the app.
        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (!isPlaying) savePosition(exo)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED || playbackState == Player.STATE_READY) {
                    savePosition(exo)
                }
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                savePosition(exo)
            }
        })

        exo.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioInputFormatChanged(
                eventTime: AnalyticsListener.EventTime,
                format: Format,
                decoderReuseEvaluation: DecoderReuseEvaluation?
            ) {
                title = "GX1 Player b${BuildConfig.BUILD_NUMBER} - ${format.sampleMimeType ?: "audio"} " +
                        if (passthrough) "[passthrough]" else "[PCM]"
            }
        })

        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
            .build()

        val resumeAt = prefs.getLong(posKey(uri), 0L)
        exo.setMediaItem(buildMediaItem(uri), resumeAt)
        exo.prepare()
        exo.playWhenReady = true

        playingUri = uri
        playerView.player = exo
        player = exo

        if (resumeAt > 0) {
            Toast.makeText(this, "Resumed at ${formatTime(resumeAt)}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildMediaItem(uri: Uri): MediaItem {
        val builder = MediaItem.Builder().setUri(uri)
        val subtitleConfigs = listOfNotNull(
            subtitle1Uri?.let { subtitleConfiguration(it, "Subtitle 1") },
            subtitle2Uri?.let { subtitleConfiguration(it, "Subtitle 2") }
        )
        if (subtitleConfigs.isNotEmpty()) {
            builder.setSubtitleConfigurations(subtitleConfigs)
        }
        return builder.build()
    }

    private fun releasePlayer() {
        player?.let {
            savePosition(it)
            it.release()
        }
        player = null
        playingUri = null
        playerView.player = null
    }

    // ---------- resume ----------

    private fun savePosition(exo: ExoPlayer) {
        val uri = playingUri ?: return
        if (exo.playbackState == Player.STATE_IDLE) return
        val pos = exo.currentPosition
        val dur = exo.duration
        val finished = dur != C.TIME_UNSET && dur > 0 && pos >= dur - END_MARGIN_MS
        val editor = prefs.edit()
        if (finished || pos < MIN_RESUME_MS) {
            editor.remove(posKey(uri))
        } else {
            editor.putLong(posKey(uri), pos)
        }
        editor.apply()
    }

    // ---------- subtitles ----------

    private fun toggleSubtitles() {
        subtitlesEnabled = !subtitlesEnabled
        prefs.edit().putBoolean(KEY_SUBS_ON, subtitlesEnabled).apply()
        player?.let {
            it.trackSelectionParameters = it.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subtitlesEnabled)
                .build()
        }
        Toast.makeText(this, if (subtitlesEnabled) "Subtitles on" else "Subtitles off", Toast.LENGTH_SHORT).show()
    }

    private fun removeExternalSubtitle(slot: Int) {
        if (slot == 1) subtitle1Uri = null else subtitle2Uri = null
        mediaUri?.let { video ->
            val key = if (slot == 1) KEY_SUBTITLE_1 + video else KEY_SUBTITLE_2 + video
            prefs.edit().remove(key).apply()
        }
        startPlayer()
    }

    private fun subtitleConfiguration(uri: Uri, fallbackLabel: String): MediaItem.SubtitleConfiguration {
        val name = displayName(uri)
        val mime = subtitleMime(name)
        return MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setLabel("$fallbackLabel: $name")
            .setSelectionFlags(if (fallbackLabel == "Subtitle 1") C.SELECTION_FLAG_DEFAULT else 0)
            .build()
    }

    private fun subtitleMime(name: String): String = when {
        name.endsWith(".vtt", ignoreCase = true) -> MimeTypes.TEXT_VTT
        name.endsWith(".ssa", ignoreCase = true) || name.endsWith(".ass", ignoreCase = true) -> MimeTypes.TEXT_SSA
        name.endsWith(".ttml", ignoreCase = true) || name.endsWith(".xml", ignoreCase = true) -> MimeTypes.APPLICATION_TTML
        else -> MimeTypes.APPLICATION_SUBRIP   // .srt and anything else
    }

    private fun displayName(uri: Uri): String =
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment ?: "subtitle"

    // ---------- menu ----------

    private fun showMenu() {
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        fun add(label: String, action: () -> Unit) {
            labels += label
            actions += action
        }

        add("Open video file") { pickVideo.launch(arrayOf("video/*", "audio/*")) }
        add("Resume last video") {
            val last = prefs.getString(KEY_LAST_URI, null)?.let { Uri.parse(it) }
            if (last != null) {
                selectMedia(last)
                startPlayer()
            } else {
                Toast.makeText(this, "No previous video", Toast.LENGTH_SHORT).show()
            }
        }
        add("Load Subtitle 1 (.srt / .ass)") {
            pickingSubtitleSlot = 1
            pickSubtitle.launch(arrayOf("*/*"))
        }
        add("Load Subtitle 2 (.srt / .ass)") {
            pickingSubtitleSlot = 2
            pickSubtitle.launch(arrayOf("*/*"))
        }
        if (subtitle1Uri != null) add("Remove Subtitle 1") { removeExternalSubtitle(1) }
        if (subtitle2Uri != null) add("Remove Subtitle 2") { removeExternalSubtitle(2) }
        add(if (subtitlesEnabled) "Subtitles: On (select to turn off)" else "Subtitles: Off (select to turn on)") {
            toggleSubtitles()
        }
        add(if (passthrough) "Audio pass-through: On (select to turn off)" else "Audio pass-through: Off (select to turn on)") {
            togglePassthrough()
        }
        add("Restart current video") {
            mediaUri?.let { uri ->
                prefs.edit().remove(posKey(uri)).apply()
                startPlayer()
            }
        }
        add("Build info") { showBuildInfo() }

        AlertDialog.Builder(this)
            .setTitle("GX1 Player")
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun togglePassthrough() {
        passthrough = !passthrough
        prefs.edit().putBoolean(KEY_PASSTHROUGH, passthrough).apply()
        Toast.makeText(
            this,
            if (passthrough) "Audio pass-through ON (bitstream)" else "Audio pass-through OFF (decode on box)",
            Toast.LENGTH_SHORT
        ).show()
        // Renderers can only be chosen at player creation, so rebuild (resumes at saved position).
        startPlayer()
    }

    private fun showBuildInfo() {
        AlertDialog.Builder(this)
            .setTitle("Build info")
            .setMessage("Version ${BuildConfig.VERSION_NAME}\nBuild ${BuildConfig.BUILD_NUMBER}")
            .setPositiveButton("OK", null)
            .show()
    }

    // ---------- helpers ----------

    private fun takePermission(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
            // Not every provider grants persistable permissions; playback still works this session.
        }
    }

    private fun formatTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_MENU,
            KeyEvent.KEYCODE_INFO,
            KeyEvent.KEYCODE_BUTTON_Y -> {
                showMenu()
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }
}
